console.log('cookie ',document.cookie)
// 버튼을 누르면 모든 체크박스를 선택하는 함수
function rec_checkAll() {
    var checkboxes = document.getElementsByClassName("rec-Checkbox"); // 클래스 이름으로 모든 체크박스를 선택
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true; // 각 체크박스를 체크
    }
}
function fav_checkAll() {
    var checkboxes = document.getElementsByClassName("fav-Checkbox"); 
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true; 
    }
}
// 버튼을 누르면 모든 체크박스를 해제하는 함수
function rec_uncheckAll() {
    var checkboxes = document.getElementsByClassName("rec-Checkbox"); // 클래스 이름으로 모든 체크박스를 선택 해제
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false; // 각 체크박스를 해제
    }
}
function fav_uncheckAll() {
    var checkboxes = document.getElementsByClassName("fav-Checkbox"); 
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false; 
    }
}

let preview_background = null;  // 백그라운드 정보 저장용
// preview의 백그라운드 설정
document.querySelectorAll('input[name="background"]')
   .forEach(radio => {
       radio.addEventListener('change', (e) => {
           const imageUrl = e.target.value;
           const preview = document.querySelector('.preview');
           preview.style.backgroundImage = `url(${imageUrl})`;

           preview_background = preview.style.backgroundImage // 현재 백그라운드 url을 저장
           console.log("url확인",preview_background)
   });
});

const back_img_apply = document.querySelector("#apply_btn")


back_img_apply.addEventListener('click',(e)=>{
    let prfe_back_img = document.querySelector(".prfe-wrap");
    document.cookie = `bg_url=${preview_background}`;
    console.log('cookie ',document.cookie)
    
    location.href="/음원스트리밍/음원사이트v2/myinfo.html"
    
    //prfe_back_img.style.backgroundImage = `${preview_background}`;
})



