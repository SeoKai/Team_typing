document.querySelectorAll('input[name="background"]')
    .forEach(radio => {
        radio.addEventListener('change', (e) => {
            const imageUrl = e.target.value;
            console.log(imageUrl)
            console.log(e.target)
            console.log('image URL:', imageUrl);
            const preview = document.querySelector('.preview');
            preview.style.backgroundImage = `url(${imageUrl})`;
    });
});