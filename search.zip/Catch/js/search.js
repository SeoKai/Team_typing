const art_body = document.querySelector('.art_body')
const art_next = document.querySelector('.art_next')
const art_prev = document.querySelector('.art_prev')
const art_over = document.querySelector('.art_over_body')
const art_list = document.querySelector('.art_list')


const art_overW = art_over.clientWidth
const art_listW = art_list.clientWidth
const art_bodyw = art_body.clientWidth
const art_bodyW = art_body.getBoundingClientRect()
const run = art_bodyW.width
const runW = parseFloat(run.toFixed(2))
console.log(runW)

let cnt = 0


art_next.addEventListener(('click'), () => {
    const art_body = document.querySelector('.art_body')
    const art_bodyW = art_body.getBoundingClientRect()
    const run = art_bodyW.width
    const runW = parseFloat(run.toFixed(2))
    console.log(cnt)
    ++cnt;

    if(cnt <= art_overW / art_bodyw) {
        cnt++;
    if (cnt <= art_overW / art_bodyw) {
        art_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }
    
    if (cnt <= 0) {
        cnt = 1
        art_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }
}


})

art_prev.addEventListener(('click'), () => {
    --cnt;
    console.log(cnt)
    
    const art_body = document.querySelector('.art_body')
    const art_bodyW = art_body.getBoundingClientRect()
    const run = art_bodyW.width
    const runW = parseFloat(run.toFixed(2))

    if (cnt >= 0 & cnt <= art_overW / art_bodyw) {
        art_over.style.transform = `translateX( -${runW * cnt}px)`;
    }

    if(cnt > art_overW / art_bodyw){
        cnt = 3
        art_over.style.transform = `translateX( -${runW * cnt}px)`;
    }

})

// ------------------------------------------- music




const music_next = document.querySelector('.music_next')
const music_prev = document.querySelector('.music_prev')




music_next.addEventListener(('click'), () => {
    const music_over = document.querySelector('.music_over')
    const music_overW = music_over.clientWidth
    
    const music_body = document.querySelector('.music_body')
    const music_bodyW = music_body.getBoundingClientRect()
    const music_bodyw = music_body.clientWidth
    
    const run = music_bodyW.width
    const runW = parseFloat(run.toFixed(2))
    console.log(cnt)
    ++cnt;
    if (cnt < music_overW / music_bodyw) {
        music_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }
    


    if(cnt > music_overW / music_bodyw){
        cnt = 3
        music_over.style.transform = `translateX( -${runW * cnt}px)`;
    }

})





music_prev.addEventListener(('click'), () => {
    --cnt;
    const music_over = document.querySelector('.music_over')
    const music_overW = music_over.clientWidth
    
    const music_body = document.querySelector('.music_body')
    const music_bodyW = music_body.getBoundingClientRect()
    const music_bodyw = music_body.clientWidth
    
    const run = music_bodyW.width
    const runW = parseFloat(run.toFixed(2))
    console.log(cnt)

    if (cnt >= 0 & cnt <= music_overW / music_bodyw) {
        music_over.style.transform = `translateX( -${runW * cnt}px)`;
    }



    if (cnt <= 0) {
        cnt = 0
        music_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }

})



//-------------------------- 앨범 ----------------------
const album_next = document.querySelector('.album_next')
const album_prev = document.querySelector('.album_prev')




album_next.addEventListener(('click'), () => {
    const album_over = document.querySelector('.album_over')
    const album_overW = album_over.clientWidth

    const album_body = document.querySelector('.album_body')
    const album_bodyW = album_body.getBoundingClientRect()
    const album_bodyw = album_body.clientWidth
    
    const run = album_bodyW.width
    const runW = parseFloat(run.toFixed(2))
    console.log(cnt)
    ++cnt;
    if (cnt < album_overW / album_bodyw) {
        album_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }
    
    if (cnt <= 0) {
        cnt = 0
        album_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }



})





album_prev.addEventListener(('click'), () => {
    --cnt;
    const album_over = document.querySelector('.album_over')
    const album_overW = album_over.clientWidth
    
    const album_body = document.querySelector('.album_body')
    const album_bodyW = album_body.getBoundingClientRect()
    const album_bodyw = album_body.clientWidth
    
    const run = album_bodyW.width
    const runW = parseFloat(run.toFixed(2))
    console.log(cnt)

    if (cnt >= 0 & cnt <= album_overW / album_bodyw) {
        album_over.style.transform = `translateX( -${runW * cnt}px)`;
    }

    if(cnt > album_overW / album_bodyw){
        cnt = 3
        album_over.style.transform = `translateX( -${runW * cnt}px)`;
    }

})









//----------------------- 뮤비 -----------------------

const mv_next = document.querySelector('.mv_next')
const mv_prev = document.querySelector('.mv_prev')




mv_next.addEventListener(('click'), () => {
    const mv_over = document.querySelector('.mv_over')
    const mv_overW = mv_over.clientWidth
    
    const mv_body = document.querySelector('.mv_body')
    const mv_bodyW = mv_body.getBoundingClientRect()
    const mv_bodyw = mv_body.clientWidth
    
    const run = mv_bodyW.width
    const runW = parseFloat(run.toFixed(2))
    console.log(cnt)
    ++cnt;
    if (cnt < mv_overW / mv_bodyw) {
        mv_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }
    
    if (cnt <= 0) {
        cnt = 0
        mv_over.style.transform = `translateX( -${(runW) * cnt}px)`;
    }

})





mv_prev.addEventListener(('click'), () => {
    --cnt;
    const mv_over = document.querySelector('.mv_over')
    const mv_overW = mv_over.clientWidth
    
    const mv_body = document.querySelector('.mv_body')
    const mv_bodyW = mv_body.getBoundingClientRect()
    const mv_bodyw = mv_body.clientWidth
    
    const run = mv_bodyW.width
    const runW = parseFloat(run.toFixed(2))
    console.log(cnt)

    if (cnt > 0 & cnt <= mv_overW / mv_bodyw) {
        mv_over.style.transform = `translateX( -${runW * cnt}px)`;
    }

    if(cnt >= mv_overW / mv_bodyw){
        cnt = 3
        mv_over.style.transform = `translateX( -${runW * cnt}px)`;
    }

})