console.log('cookie ',document.cookie)

let preview_background = '/음원스트리밍/음원사이트v2/img/prfe_background_image.png';  // 백그라운드 정보 저장용
// preview의 백그라운드 설정
document.querySelectorAll('input[name="background"]')
   .forEach(radio => {
       radio.addEventListener('change', (e) => {
           const imageUrl = e.target.value;
           const preview = document.querySelector('.preview');
           preview.style.backgroundImage = `url(${imageUrl})`;

           preview_background = imageUrl // 현재 백그라운드 url을 저장
           console.log("url확인",preview_background)
   });
});

const back_img_apply = document.querySelector("#back_img_apply")

back_img_apply.addEventListener('click',(e)=>{
    
    document.cookie = `${preview_background}`;
    console.log('cookie ',document.cookie);
    
})






