// 쿠키 확인
console.log('cookie ',document.cookie)


// 버튼을 누르면 모든 체크박스를 선택하는 함수
function rec_checkAll() {
    var checkboxes = document.getElementsByClassName("rec-Checkbox"); // 클래스 이름으로 모든 체크박스를 선택
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true; // 각 체크박스를 체크
    }
}
function fav_checkAll() {
    var checkboxes = document.getElementsByClassName("fav-Checkbox"); 
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true; 
    }
}
// 버튼을 누르면 모든 체크박스를 해제하는 함수
function rec_uncheckAll() {
    var checkboxes = document.getElementsByClassName("rec-Checkbox"); // 클래스 이름으로 모든 체크박스를 선택 해제
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false; // 각 체크박스를 해제
    }
}
function fav_uncheckAll() {
    var checkboxes = document.getElementsByClassName("fav-Checkbox"); 
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false; 
    }
}

if (document.cookie != null) {
    const backimg = document.querySelector(".prfe-wrap");
    backimg.style.backgroundImage = `url(${document.cookie})`;
    console.log('백그라운드 이미지 설정:', document.cookie);
}



