// 쿠키 확인
console.log('쿠키를 확인해봅시다',document.cookie)


// 버튼을 누르면 모든 체크박스를 선택하는 함수
function rec_checkAll() {
    var checkboxes = document.getElementsByClassName("rec-Checkbox"); // 클래스 이름으로 모든 체크박스를 선택
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true; // 각 체크박스를 체크
    }
}
function fav_checkAll() {
    var checkboxes = document.getElementsByClassName("fav-Checkbox"); 
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true; 
    }
}
// 버튼을 누르면 모든 체크박스를 해제하는 함수
function rec_uncheckAll() {
    var checkboxes = document.getElementsByClassName("rec-Checkbox"); // 클래스 이름으로 모든 체크박스를 선택 해제
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false; // 각 체크박스를 해제
    }
}
function fav_uncheckAll() {
    var checkboxes = document.getElementsByClassName("fav-Checkbox"); 
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false; 
    }
}

if (document.cookie != null) {
    const backimg = document.querySelector(".prfe-wrap");
    backimg.style.backgroundImage = `url(${document.cookie})`;
}

// console.log(cookie_Array)
// console.log(cookie_Array[0])
// console.log(cookie_Array[1])
// console.log(cookie_Array[2])
// console.log(cookie_Array[1].substring(1));
// console.log(cookie_Array[0].split("="))
// console.log(cookie_Array[1].split("="))
// console.log(cookie_Array[2].split("="))
// console.log(cookie_Array[2].slice("="))

// const [name0,value0] = cookie_Array[0].split("=");
// const [name1,value1] = cookie_Array[1].split("=");
// const [name2,value2] = cookie_Array[2].split("=");

// console.log(name0)
// console.log(name1)
// console.log(name2)

// console.log(value0)
// console.log(value1)
// console.log(value2)

// const [key,value] = cookie_Array.split("=");
// console.log(key)
// console.log(value)
const cookie_Array = document.cookie.split(';');

for(let i=0;i<cookie_Array.length;i++){
    let [key,value] = cookie_Array[i].split("=");
    console.log(key)
    console.log(value)
    if(key === " bg_img"){
        const bg_img_value = value.trim();
        const bg_img = document.querySelector(".prfe-wrap");

        bg_img.style.backgroundImage=`url(${bg_img_value})`
    }
    if(key === " intro_text"){
        const intro_text_value = value.trim();

        const intro_text = document.querySelector(".intro_prfe");

        //기존 소개글 제거
        const oldspan = intro_text.querySelector("span"); 
        if(oldspan != null){
            oldspan.remove()
        }
        //intro_text_value를 span태그로 추가
        const newspan = document.createElement("span")
        newspan.innerHTML= intro_text_value;
        intro_text.appendChild(newspan);
    }
}

const slider = document.querySelector(".slider"); 
const list = document.querySelectorAll('ul.item li'); 
let currentIndex = 0; 

// 슬라이드 이동
function moveSlide(index) {
    const slideWidth = list[0].clientWidth;
    slider.style.transform = `translateX(${-slideWidth * index}px)`;
}

// 다음 슬라이드로 이동
document.querySelector("label.next").addEventListener('click', () => {
    if (currentIndex < list.length - 1) { // 마지막 슬라이드가 아닐 때만 이동
        currentIndex++; 
        moveSlide(currentIndex); // 새로운 인덱스에 맞춰 슬라이드 이동
    }
});

// 이전 슬라이드로 이동하는 이벤트 리스너
document.querySelector("label.prev").addEventListener('click', () => {
    if (currentIndex > 0) { // 첫 번째 슬라이드가 아닐 때만 이동
        currentIndex--; 
        moveSlide(currentIndex); // 새로운 인덱스에 맞춰 슬라이드 이동
    }
});

// 화면 크기 변경 시 현재 슬라이드에 맞춰 위치 재조정
window.addEventListener('resize', () => {
    moveSlide(currentIndex); // 화면 크기가 변경되면 현재 인덱스에 맞춰 슬라이드 재정렬
});
